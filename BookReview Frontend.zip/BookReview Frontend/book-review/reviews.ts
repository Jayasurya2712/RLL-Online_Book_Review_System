export class User{
    name:string
    email:string
    password:string
}
export class Book{
    id:number
    name:string
    author:string
    description:string
    price:number
    category:string
    enable:string
}

export class Reviews{
    uname:string;
	review:string;
	rating:string;
	bname:string;
}
